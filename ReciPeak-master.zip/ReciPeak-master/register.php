<?php 
     require "conn.php";
	 $name= $_POST["name"];
	 $email= $_POST["email"];
	 $password= $_POST["password"]; 
	 
	 
	 $isValidEmail = filter_var($email, FILTER_VALIDATE_EMAIL);
	 if($conn){
		 if(strlen($password)>40 || strlen($password)<6){
			 echo "Password length invalid. Must be between 6 and 40";
		 }
	  
		else if($isValidEmail==false){
		 echo "Email invalid.";
	 }
	 
		else{
			$sqlCheckName = "SELECT * FROM `users_table` WHERE `name` LIKE '$name'";
			$nameQuery1= mysqli_query($conn, $sqlCheckName);
			$sqlCheckEmail = "SELECT * FROM `users_table` WHERE `email` LIKE '$email'";
			$nameQuery= mysqli_query($conn, $sqlCheckEmail);
     if(mysqli_num_rows($nameQuery1)>0){
		 echo "Username already in use";
	 }
	 else if(mysqli_num_rows($nameQuery) > 0){
		 echo "This email is already registered.";
	 }
     else {
		     $sql = "INSERT INTO `users_table` (`name`, `email`, `password`) VALUES ('$name', '$email', '$password')";
		 if(mysqli_query($conn, $sql)){
			 echo "Account created";
		 }
		 else{
			 echo "Registration failed";
		 }
	 }
	 
		}
	 }
	 else {
		 echo "connection error";
	 }
		
		
?>
<?php 
          require "conn.php";
		  $email= $_POST["email"];
	      $password= $_POST["password"]; 
		   $isValidEmail = filter_var($email, FILTER_VALIDATE_EMAIL);
		   if($conn){
			   
		   }
		   else{
			   echo "Connection error.";
		   }
     if($isValidEmail==false){
		 echo "Email invalid.";
	 }
	 else{
		 $sqlCheckEmail = "SELECT * FROM `users_table` WHERE `email` LIKE '$email'";
		 $nameQuery= mysqli_query($conn, $sqlCheckEmail);
		 if(mysqli_num_rows($nameQuery) > 0){
		  $sqlLogin = "SELECT * FROM `users_table` WHERE `email` LIKE '$email' AND `password` LIKE '$password'";
		  $loginQuery = mysqli_query($conn, $sqlLogin);
		  		if(mysqli_num_rows($loginQuery) > 0){
					echo "Login successful";
				}
				else{
					echo "Wrong password";
				}
	     
		 }
		 else{
			echo "This email is not registered.";
		 }
	 }

?>
<?php 
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "users_recipeak";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);



?>